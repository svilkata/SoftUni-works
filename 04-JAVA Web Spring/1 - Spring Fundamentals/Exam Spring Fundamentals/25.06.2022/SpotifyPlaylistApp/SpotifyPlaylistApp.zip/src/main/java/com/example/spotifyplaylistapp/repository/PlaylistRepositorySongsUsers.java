package com.example.spotifyplaylistapp.repository;

import com.example.spotifyplaylistapp.model.entity.PlaylistEntitySongsUsers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PlaylistRepositorySongsUsers extends JpaRepository<PlaylistEntitySongsUsers, Long> {
}
