package com.example.spotifyplaylistapp.model.entity.enums;

public enum StyleEnum {
    POP, ROCK, JAZZ
}
