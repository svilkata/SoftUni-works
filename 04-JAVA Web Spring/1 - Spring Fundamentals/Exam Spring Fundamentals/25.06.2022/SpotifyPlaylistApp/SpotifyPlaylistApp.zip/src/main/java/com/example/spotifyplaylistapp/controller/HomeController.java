package com.example.spotifyplaylistapp.controller;

import com.example.spotifyplaylistapp.security.LoggedUser;
import com.example.spotifyplaylistapp.service.SongsServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    private final LoggedUser loggedUser;
    private final SongsServiceImpl songsService;

    public HomeController(LoggedUser loggedUser, SongsServiceImpl songsService) {
        this.loggedUser = loggedUser;
        this.songsService = songsService;
    }

    @GetMapping("/")
    public String loggedOutIndex(){
        //if user is already logged-in
        if (loggedUser.getId() != null) {
            return "redirect:/home";
        }

        return "index";
    }

    @GetMapping("/home")
    public String loggedInIndex(Model model){
        //if user is logged-out
        if (loggedUser.getId() == null) {
            return "redirect:/";
        }

        model.addAttribute("popSongs", this.songsService.getAllSongs().getPopSongs());
        model.addAttribute("rockSongs", this.songsService.getAllSongs().getRockSongs());
        model.addAttribute("jazzSongs", this.songsService.getAllSongs().getJazzSongs());
        model.addAttribute("currentUserPlaylistSongs", this.songsService.getAllSongs().getCurrentUserPlaylistSongs());

        return "home";
    }

    @GetMapping("/addToPlaylist")
    public String addToPlaylist(Model model){
        //TODO: add the song in PlaylistEntitySongsUsers  database

        return "redirect:home";
    }


}
