package com.demo.springbootsecurityjwtdemo.service.validation;

public interface EmailValidationService extends ValidationService {
}
