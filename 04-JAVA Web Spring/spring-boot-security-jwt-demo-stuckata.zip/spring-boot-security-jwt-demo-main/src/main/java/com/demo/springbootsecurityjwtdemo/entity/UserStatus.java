package com.demo.springbootsecurityjwtdemo.entity;

public enum UserStatus {
    ACTIVE,
    TERMINATED
}
