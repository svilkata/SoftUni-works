package com.demo.springbootsecurityjwtdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityJwtDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityJwtDemoApplication.class, args);
	}

}
