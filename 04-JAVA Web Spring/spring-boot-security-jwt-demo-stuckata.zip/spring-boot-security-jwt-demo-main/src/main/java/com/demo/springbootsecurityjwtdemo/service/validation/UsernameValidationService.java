package com.demo.springbootsecurityjwtdemo.service.validation;

public interface UsernameValidationService extends ValidationService {

}
