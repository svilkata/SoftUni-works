package com.demo.springbootsecurityjwtdemo.entity;

public enum UserRole {
    USER,
    ADMIN
}
