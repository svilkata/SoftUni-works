package _05_BillsPaymentSystem;

import _04_HospitalDatabase.entities.Diagnose;
import _04_HospitalDatabase.entities.Medicament;
import _04_HospitalDatabase.entities.Patient;
import _04_HospitalDatabase.entities.Visitation;
import _05_BillsPaymentSystem.entities.BankAccount;
import _05_BillsPaymentSystem.entities.BillingDetail;
import _05_BillsPaymentSystem.entities.CreditCard;
import _05_BillsPaymentSystem.entities.User;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class _05Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa_relations_exc");
        EntityManager entityManager = emf.createEntityManager();

        entityManager.getTransaction().begin();

        CreditCard billingDetail1 = new CreditCard("987654321", "Bash maistora", "MASTERCARD",
                "08", "24");
        BankAccount billingDetail2 = new BankAccount("111222333", "Bash maistora", "OBB",
                "UBBS12D4");

        CreditCard billingDetail3 = new CreditCard("12345678", "Svilen Velikov", "VISA",
                "10", "23");
        BankAccount billingDetail4 = new BankAccount("333222111", "Svilen Velikov", "Bulbank",
                "BBBU12Z4");
        BankAccount billingDetail5 = new BankAccount("999888777", "Svilen Velikov", "Bulbank",
                "BBBU12Z4");

        entityManager.persist(billingDetail1);
        entityManager.persist(billingDetail2);
        entityManager.persist(billingDetail3);
        entityManager.persist(billingDetail4);
        entityManager.persist(billingDetail5);


        User user1 = new User("Bash", "Maistora", "mymail@abv.bg", "mypassword");
        user1.addCreditCard(billingDetail1);
        user1.addBankAccount(billingDetail2);

        User user2 = new User("Svilen", "Velikov", "svill@abv.bg", "mypasswordYee");
        user2.addCreditCard(billingDetail3);
        user2.addBankAccount(billingDetail4);
        user2.addBankAccount(billingDetail5);

        entityManager.persist(user1);
        entityManager.persist(user2);


        entityManager.getTransaction().commit();
        entityManager.close();
    }
}



