package _05_BillsPaymentSystem.entities;

import javax.persistence.*;

@MappedSuperclass //нещо междинно го анотира
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class BillingDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  int id;

    @Column(nullable = false, unique = true)
    private String number;

    @Column(nullable = false)
    private String owner;

    protected BillingDetail() {
    }

    protected BillingDetail(String number, String owner) {
        this.number = number;
        this.owner = owner;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }
}
