package demo.services;


public interface BookService {


}
