package demo.entities;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
