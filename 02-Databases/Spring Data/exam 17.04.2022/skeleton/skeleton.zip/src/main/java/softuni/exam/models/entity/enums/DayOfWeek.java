package softuni.exam.models.entity.enums;

public enum DayOfWeek {
    FRIDAY, SATURDAY, SUNDAY
}
