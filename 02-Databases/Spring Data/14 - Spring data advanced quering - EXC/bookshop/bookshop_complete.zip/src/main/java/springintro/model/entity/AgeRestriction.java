package springintro.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
