package springintro.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
