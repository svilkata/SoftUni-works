package bg.jug.academy.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseMetadataExamples {

	public static void main(String[] args) throws SQLException {

		Connection dbCon = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// Load the Oracle JDBC driver
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException ex) {
				throw new DatabaseException(
						"Can not load the JDBC driver class", ex);
			}

			// Establish connection to Oracle 10g Express Edition
			try {
				dbCon = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/hrm",
						"root", "admin");
			} catch (SQLException sqlex) {
				throw new DatabaseException("Can not establish connection",
						sqlex);
			}
			
			// retrieve database metadata from the connection
			try {
				
				CallableStatement call = dbCon.prepareCall("{call print_employee_info(?)}");
				call.setString(1, "test@test.com");
				call.execute();
						DatabaseMetaData metadata = dbCon.getMetaData();
				System.err.println("RDBMS name: "
						+ metadata.getDatabaseProductName());
				System.err.println("RDBMS version: "
						+ metadata.getDatabaseProductVersion());
				System.err.println("HRM visible schemas: ");
				ResultSet schemas = metadata.getSchemas();
				while (schemas.next()) {
					System.err.println(" - " + schemas.getString(1));
				}

				ResultSet hrmTables = metadata.getTables(null, "HRM",
						null, null);
				System.err.println("HRM schema tables: ");
				while (hrmTables.next()) {
					System.err.println(" * " + hrmTables.getString(3));
				}

				// retrieve database metadata from the ResultSet
				ResultSetMetaData resultMetadata = hrmTables.getMetaData();
				int columnCount = resultMetadata.getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					System.err.println(String.format(
							"Column name: '%s', column type: '%s'.",
							resultMetadata.getColumnName(i),
							resultMetadata.getColumnTypeName(i)));
				}
				
			} catch (SQLException e) {
				throw new DatabaseException(
						"Failed to retrieve database metadata.", e);
			}
		} catch (DatabaseException dbex) {
			dbex.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlex) {
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException sqlex) {
				}
			}
			if (dbCon != null) {
				try {
					dbCon.close();
				} catch (SQLException sqlex) {
				}
			}
		}
	}

}
