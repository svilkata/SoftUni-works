package bg.jug.academy.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BasicExamples {

	private static final Logger LOGGER = Logger.getLogger(BasicExamples.class.getName());
	
	public static void main(String[] args) throws ClassNotFoundException {

//		createBatchExample();
//		createTransactionExample();
//		getDatabaseMetadataExample();
//		callStoredProcedureExample();
//		createPreparedStatementExample(3, "Ivan Ivanov");
//		createExample();
//		selectExample();
//		insertExample();
	}

	private static void createBatchExample() throws ClassNotFoundException {
		Connection connection = null;
		try {
			connection = createConnection();
			PreparedStatement insert = 
					connection.prepareStatement("INSERT INTO test2(ID, NAME) VALUES (?, ?)");
			for(int i = 100; i < 110; i++) {
				insert.setInt(1, i);
				insert.setString(2, "Ivan Ivanov");
				insert.addBatch();
			}
			insert.executeBatch();
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		} finally {
			closeConnection(connection);
		}		
	}

	private static void createTransactionExample() throws ClassNotFoundException {
		Connection connection = null;
		try {
			connection = createConnection();
			connection.setAutoCommit(false);
			PreparedStatement insert = 
					connection.prepareStatement("INSERT INTO test3(ID, NAME) VALUES (?, ?)");
			for(int i = 100; i < 110; i++) {
				insert.setInt(1, i);
				insert.setString(2, "Ivan Ivanov");
				int result = insert.executeUpdate();
				LOGGER.info("Insert query result: " + result);
			}
			connection.commit();
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
			try {
				connection.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} finally {
			closeConnection(connection);
		}
	}

	private static void getDatabaseMetadataExample() throws ClassNotFoundException {
		try(Connection connection = createConnection()) {
			DatabaseMetaData metadata = connection.getMetaData();
			ResultSet tables = metadata.getTables(null, "HRM", null, null);
			while(tables.next()) {
				System.out.println(tables.getString(3));
				ResultSetMetaData tableMetadata = tables.getMetaData();
				for(int i = 1; i <= tableMetadata.getColumnCount(); i++) {
					System.err.println(String.format(
							"Column name: '%s', column type: '%s'.",
							tableMetadata.getColumnName(i),
							tableMetadata.getColumnTypeName(i)));
				}
			}
			
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}

	private static void callStoredProcedureExample() throws ClassNotFoundException {
		try(Connection connection = createConnection()) {
			CallableStatement statement = 
					connection.prepareCall("call print_employee_info(?)");
			statement.setString(1, "test@test.com");
			statement.execute();
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}

	private static void createPreparedStatementExample(int id, String name) throws ClassNotFoundException {
		try(Connection connection = createConnection();
				Statement statement = connection.createStatement()) {
			statement.executeUpdate("CREATE TABLE test3(ID INTEGER, NAME VARCHAR(200))");
			PreparedStatement insert = 
					connection.prepareStatement("INSERT INTO test3(ID, NAME) VALUES (?, ?)");
			for(int i = 0; i < 10; i++) {
				insert.setInt(1, id + i);
				insert.setString(2, name);
				int result = insert.executeUpdate();
				LOGGER.info("Insert query result: " + result);
			}
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}

	private static void createExample() throws ClassNotFoundException {
		try(Connection connection = createConnection();
				Statement statement = connection.createStatement()) {
			int result = statement.executeUpdate("CREATE TABLE test2(ID INTEGER, NAME VARCHAR(200))");
			statement.executeUpdate("INSERT INTO test2(ID, NAME) VALUES (1, 'some name')");
			LOGGER.info("Insert query result: " + result);
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}

	private static void insertExample() throws ClassNotFoundException {
		try(Connection connection = createConnection();
				Statement statement = connection.createStatement()) {
			int result = statement.executeUpdate("INSERT INTO employees(Id, Name, Email, Salary, DepartmentId, TitleId, Phone, HireDate)" + 
					" VALUES (100, 'Martin Toshev', 'test@abv.bg', 1000, 1, 1, '00000', '2023-09-05')");
			LOGGER.info("Insert query result: " + result);
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}
	}

	public static Connection createConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/hrm",
				"root", "admin");
		
		return connection;
	}
	
	public static void closeConnection(Connection connection) {

		if(connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				LOGGER.log(Level.WARNING, e.getMessage(), e);
			}
		}
	}
	
	private static void selectExample() throws ClassNotFoundException {
		Connection connection = null;
		Statement statement = null;
		ResultSet result = null;
		try {
			connection = createConnection();
			statement = connection.createStatement();
			result = statement.executeQuery("SELECT Name, Email, Salary, DepartmentId from employees");
			while(result.next()) {
				String name = result.getString("Name");
				String email = result.getString("email");
				int salary = result.getInt("Salary");
				int departmentId = result.getInt("DepartmentId");
				LOGGER.info(String.format("Name: %s, email: %s, salary: %d, deparment ID: %d", 
						name, email, salary, departmentId));
			}
		} catch(SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		} finally {
			if(result != null) {
				try {
					result.close();
				} catch (SQLException e) {
					LOGGER.log(Level.WARNING, e.getMessage(), e);
				}
			}
			
			if(statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					LOGGER.log(Level.WARNING, e.getMessage(), e);
				}
			}

			closeConnection(connection);
		}		
	}
	
}
