package bg.jug.academy.jdbc;
public class DatabaseException extends Exception {
	private static final long serialVersionUID = 937357450431508754L;

	public DatabaseException(String message, Throwable cause) {
		super(message, cause);
	}
}
