import implementations.Tree;
import implementations.TreeFactory;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        String[] input = {
//                "19 1",
//                "19 12",
//                "19 31",
//                "14 23",
//                "14 6",
//                "7 19",
//                "7 21",
//                "7 14"
//        };
//
//        TreeFactory treeFactory = new TreeFactory();
//        Tree<Integer> tree = treeFactory.createTreeFromStrings(input);
//        System.out.println(tree.getAsString());
//
//
//        int b = 5;



    }
}
