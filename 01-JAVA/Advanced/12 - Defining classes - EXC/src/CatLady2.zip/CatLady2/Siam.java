package CatLady2;

public class Siam {
    private String catType;
    private double earSize;

    public Siam(String catType, double earSize) {
        this.catType = catType;
        this.earSize = earSize;
    }

    public String getCatType() {
        return catType;
    }

    public double getEarSize() {
        return earSize;
    }
}
