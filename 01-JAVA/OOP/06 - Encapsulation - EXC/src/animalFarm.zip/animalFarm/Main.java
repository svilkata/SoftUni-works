package animalFarm;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Chicken chicken = new Chicken(sc.nextLine(), Integer.parseInt(sc.nextLine()));


//        System.out.println(chicken);
    }

}
