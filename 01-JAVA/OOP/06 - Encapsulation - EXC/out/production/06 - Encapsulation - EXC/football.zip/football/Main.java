package football;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static football.Validator.checkIfTeamPresent;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        Team team = new Team();
        List<Team> teams = new ArrayList<>();
        List<Player> players = new ArrayList<>();

        while (!"END".equals(input)) {
            String[] data = input.split(";");

            switch (data[0]) {
                case "Team": //add team
                    team = new Team(data[1]);
                    break;
                case "Add": //add player
                    try {
                        checkIfTeamPresent(team, data[1]);
                        Player playerToAdd = null;
                        try {
                            playerToAdd = new Player(data[2], Integer.parseInt(data[3]), Integer.parseInt(data[4]),
                                    Integer.parseInt(data[5]), Integer.parseInt(data[6]), Integer.parseInt(data[7]));
                            team.addPlayer(playerToAdd);
                        } catch (IllegalArgumentException e) {
                            System.out.println(e.getMessage());
                        }

                    } catch (IllegalArgumentException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
                case "Remove": //remove player
                    checkIfTeamPresent(team, data[1]);
                    try {
                        team.removePlayer(data[2]);
                    } catch (IllegalArgumentException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
                case "Rating": //print team rating
                    checkIfTeamPresent(team, data[1]);
                    System.out.println(team.getName() + " - " + Math.round(team.getRating()));
                    break;
            }

            input = sc.nextLine();
        }
    }
}
