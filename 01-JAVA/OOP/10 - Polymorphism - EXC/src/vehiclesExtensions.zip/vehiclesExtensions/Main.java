package vehiclesExtensions;

import vehiclesExtensions.garage.Bus;
import vehiclesExtensions.garage.Car;
import vehiclesExtensions.garage.Truck;
import vehiclesExtensions.garage.Vehicle;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Map<String, Vehicle> vehicles = new LinkedHashMap<>();
        vehicles.put("Car", readVehicleInput(sc.nextLine()));
        vehicles.put("Truck", readVehicleInput(sc.nextLine()));
        vehicles.put("Bus", readVehicleInput(sc.nextLine()));

        int n = Integer.parseInt(sc.nextLine());

        while (n-- > 0) {
            String[] tokens = sc.nextLine().split("\\s+");
            String command = tokens[0];
            String typeVehicle = tokens[1];
            double consumpt = Double.parseDouble(tokens[2]);

            try {
                if (command.equals("Drive") && !typeVehicle.equals("Bus")) { //case car and truck
                    vehicles.get(typeVehicle).drive(consumpt);
                } else if (command.equals("Drive")) { // case bus - with people
                    ((Bus) vehicles.get(typeVehicle)).setOccupied(true); //кастваме, за да имаме достъп до setOccupied
                    vehicles.get(typeVehicle).drive(consumpt);
                } else if (command.equals("DriveEmpty")) { //case bus - empty bus
                    ((Bus) vehicles.get(typeVehicle)).setOccupied(false); //кастваме, за да имаме достъп до setOccupied
                    vehicles.get(typeVehicle).drive(consumpt);
                } else { //refuel
                    vehicles.get(typeVehicle).refuel(consumpt);
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        vehicles.values().forEach(e -> System.out.println(e));
    }

    private static Vehicle readVehicleInput(String nextLine) {
        String[] tokens = nextLine.split("\\s+");
        double quantity = Double.parseDouble(tokens[1]);
        double consumption = Double.parseDouble(tokens[2]);
        double capacity = Double.parseDouble(tokens[3]);

        return tokens[0].equals("Car") ? new Car(quantity, consumption, capacity)
                : tokens[0].equals("Bus") ?
                new Bus(quantity, consumption, capacity)
                :
                new Truck(quantity, consumption, capacity);

    }
}
