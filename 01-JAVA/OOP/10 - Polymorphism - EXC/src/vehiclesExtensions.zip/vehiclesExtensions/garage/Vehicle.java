package vehiclesExtensions.garage;

public interface Vehicle {
    void drive(double distance);
    void refuel(double liters);
}
