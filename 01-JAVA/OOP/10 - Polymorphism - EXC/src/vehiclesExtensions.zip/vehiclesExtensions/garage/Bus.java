package vehiclesExtensions.garage;

public class Bus extends VehicleImpl implements Vehicle {
    private static final double AIR_CONDITIONER_BUS_EXTRA_CONSUMPTION = 1.4;
    private static final String CLAZZ_NAME = "Bus";

    private boolean occupied;

    public Bus(double fuelQuantity, double consumption, double capacity) {
        super(fuelQuantity, consumption, capacity);
        this.occupied = false;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    @Override
    public void drive(double distance) {
        //increase consumption if with passangers
        if (this.occupied) {
            super.addConsumptionBus(AIR_CONDITIONER_BUS_EXTRA_CONSUMPTION);
        }
        System.out.print(CLAZZ_NAME);
        super.drive(distance);
        if (this.occupied) {
            super.subtractConsumptionBus(AIR_CONDITIONER_BUS_EXTRA_CONSUMPTION);
        }
        this.setOccupied(false);
    }

    @Override
    public String toString() {
        return CLAZZ_NAME + super.toString();
    }
}
