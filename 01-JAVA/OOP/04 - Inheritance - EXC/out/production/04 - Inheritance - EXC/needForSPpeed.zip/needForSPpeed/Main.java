package needForSPpeed;

public class Main {
    public static void main(String[] args) {

        Car car = new Car(20, 45);

    }
}
