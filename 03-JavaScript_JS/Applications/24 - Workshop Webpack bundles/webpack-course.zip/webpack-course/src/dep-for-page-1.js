const pageNumber = 1;

export default pageNumber;