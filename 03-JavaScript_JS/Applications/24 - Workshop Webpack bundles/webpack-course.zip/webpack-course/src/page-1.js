import pageNumber from './dep-for-page-1';

console.log(`Hello from page ${pageNumber}`);
console.log('Hello from page-1.js');
