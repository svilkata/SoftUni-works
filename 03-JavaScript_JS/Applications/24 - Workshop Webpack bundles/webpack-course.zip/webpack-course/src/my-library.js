var MyLibrary = function() {
    console.log(1 + 1);
};

export default MyLibrary;
