package foodShortage;

public interface Birthable {
    public String getBirthDate();

}
