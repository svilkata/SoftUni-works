package foodShortage;

public interface Identifiable {
    public String getId();
}
