package foodShortage;

public interface Person extends Buyer{
    public String getName();
    public int getAge();
}
