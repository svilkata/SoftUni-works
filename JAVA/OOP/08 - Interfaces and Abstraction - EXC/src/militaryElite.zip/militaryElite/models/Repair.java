package militaryElite.models;

public interface Repair {
}
