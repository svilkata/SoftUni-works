package militaryElite.models;

public interface Mission {
    void completeMission();
}
