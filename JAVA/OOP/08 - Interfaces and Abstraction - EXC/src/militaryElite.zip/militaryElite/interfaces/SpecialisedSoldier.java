package militaryElite.interfaces;

public interface SpecialisedSoldier {
}
