package militaryElite.interfaces;

public interface Soldier{
    int getID();
    String getFirstName();
    String getLastName();
}
