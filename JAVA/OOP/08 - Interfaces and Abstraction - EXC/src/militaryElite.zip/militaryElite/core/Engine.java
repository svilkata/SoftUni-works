package militaryElite.core;

public interface Engine {
    void run();
}
