package militaryElite.utils.readers;

import java.io.IOException;

public interface InputReader {
    String readLine();
}
