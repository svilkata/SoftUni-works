package multipleImplementation;

public interface Birthable {
    public String getBirthDate();

}
