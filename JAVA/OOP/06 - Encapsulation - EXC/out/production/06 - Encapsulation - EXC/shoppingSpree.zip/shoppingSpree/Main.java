package shoppingSpree;

import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) {

        Product product = new Product("Milka", 21);

        product.getName();

    }
}
