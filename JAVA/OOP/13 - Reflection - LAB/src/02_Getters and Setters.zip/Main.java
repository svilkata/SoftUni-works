import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class reflectionClass = Reflection.class;

        /* Task 1
        System.out.println(reflectionClass);
        System.out.println(reflectionClass.getSuperclass());
        Class[] interfaces = reflectionClass.getInterfaces();
        for (Class anInterface : interfaces) {
            System.out.println(anInterface);
        }
        Object o = reflectionClass.getDeclaredConstructor().newInstance();
        System.out.println(o.toString());**/

        Method[] allMethods = reflectionClass.getDeclaredMethods();
        List<Method> setters = new ArrayList<>();
        List<Method> getters = new ArrayList<>();

        for (Method method : allMethods) {
            if (isSetter(method)) {
                setters.add(method);
            } else if (isGetter(method)) {
                getters.add(method);
            }
        }

        getters.sort(Main::compare);
        setters.sort(Main::compare);

        getters.forEach(g -> System.out.println(formatGetter(g)));
        setters.forEach(s -> System.out.println(formatSetter(s)));
    }

    private static String formatGetter(Method g) {
        return String.format("%s will return class %s",
                g.getName(), g.getReturnType().getName());
    }

    private static String formatSetter(Method s) {
        return String.format("%s and will set field of class %s",
                s.getName(), s.getParameterTypes()[0].getName());
    }

    private static int compare(Method l, Method r) {
        return l.getName().compareTo(r.getName());
    }

    private static boolean isGetter(Method method) {
        if (!method.getName().startsWith("get")) {
            return false;
        }

        if (method.getReturnType() == void.class) {
            return false;
        }

        if (method.getParameterCount() != 0) {
            return false;
        }

        return true;
    }

    private static boolean isSetter(Method method) {
        if (!method.getName().startsWith("set")) {
            return false;
        }

        if (method.getReturnType() != void.class) {
            return false;
        }

        if (method.getParameterCount() != 1) {
            return false;
        }

        return true;
    }
}
