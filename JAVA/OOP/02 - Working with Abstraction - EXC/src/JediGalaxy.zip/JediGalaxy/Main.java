package JediGalaxy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] dimentions = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();
        int rows = dimentions[0];
        int cols = dimentions[1];

        int[][] matrix = new int[rows][cols];

        int value = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = value++;
            }
        }

        String command = scanner.nextLine();
        long sum = 0;
        while (!"Let the Force be with you".equals(command)) {
            int[] playerStartPosition = Arrays.stream(command.split(" ")).mapToInt(Integer::parseInt).toArray();
            int[] enemyStartPosition = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
            int enemyRow = enemyStartPosition[0];
            int enemyCol = enemyStartPosition[1];

            while (enemyRow >= 0 && enemyCol >= 0) {
                if (enemyRow < matrix.length && enemyCol < matrix[0].length) {
                    matrix[enemyRow][enemyCol] = 0;
                }
                enemyRow--;
                enemyCol--;
            }

            int playerRow = playerStartPosition[0];
            int playerCol = playerStartPosition[1];

            while (playerRow >= 0 && playerCol < matrix[1].length) {
                if (playerRow < matrix.length && playerCol >= 0 && playerCol < matrix[0].length) {
                    sum += matrix[playerRow][playerCol];
                }

                playerRow--;
                playerCol++;
            }

            command = scanner.nextLine();
        }

        System.out.println(sum);
    }
}
