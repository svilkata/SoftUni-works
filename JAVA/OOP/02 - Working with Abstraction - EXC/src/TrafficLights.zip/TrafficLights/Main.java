package TrafficLights;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        TrafficLight[] trafficLights = Arrays.stream(sc.nextLine().split("\\s+"))
                .map(e -> TrafficLight.valueOf(e))
                .toArray(TrafficLight[]::new);

        int n = sc.nextInt();

        TrafficLight[] lights = TrafficLight.values();

        while (n-- > 0) {
            for (int i = 0; i < trafficLights.length; i++) {
                int index = (trafficLights[i].ordinal() + 1) % lights.length; //гарантираме, че не излизаме от масива
//                if (index >= lights.length) {
//                    index = 0;
//                }
                trafficLights[i] = lights[index];

                System.out.print(trafficLights[i].toString() + " ");
            }
            System.out.println();
        }

    }
}
