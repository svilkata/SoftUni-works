package wildFarm;

public class Meat extends Food {

}
