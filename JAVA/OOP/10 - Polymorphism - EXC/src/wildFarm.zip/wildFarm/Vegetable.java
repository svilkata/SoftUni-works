package wildFarm;

public class Vegetable extends Food {



}
