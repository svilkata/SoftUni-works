package wildFarm;

public abstract class Food {
     Integer quantity;
}
