package ferrari;

public interface Car {
    public String brakes();
    public String gas();

}
