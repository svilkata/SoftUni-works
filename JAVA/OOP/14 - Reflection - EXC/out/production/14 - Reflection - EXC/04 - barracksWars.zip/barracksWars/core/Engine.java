package barracksWars.core;

import barracksWars.interfaces.Executable;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.Runnable;
import barracksWars.interfaces.UnitFactory;
import jdk.jshell.spi.ExecutionControl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Engine implements Runnable {
    private final static String PACKAGE_NAME = "barracksWars.core.commands.";

    private Repository repository;
    private UnitFactory unitFactory;

    public Engine(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    public void run() {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));
        while (true) {
            try {
                String input = reader.readLine();
                String[] data = input.split("\\s+");
                String commandName = data[0];
                String result = interpretCommand(data, commandName);
                if (result.equals("fight")) {
                    break;
                }
                System.out.println(result);
            } catch (RuntimeException e) {
                System.out.println(e.getMessage());
            } catch (IOException | ExecutionControl.NotImplementedException e) {
                e.printStackTrace();
            }
        }
    }

    // TODO: refactor for problem 4
    private String interpretCommand(String[] data, String commandName) throws ExecutionControl.NotImplementedException {
        String result;

        String command = getCorrectClassName(data[0]);
        try {
            Class clazz = Class.forName(PACKAGE_NAME + command);
            Constructor constructor = clazz.getDeclaredConstructor(String[].class, Repository.class, UnitFactory.class);
            constructor.setAccessible(true);
            Executable instance = (Executable) constructor.newInstance(data, this.repository, this.unitFactory);
            result = instance.execute();
        } catch (ClassNotFoundException | NoSuchMethodException
                | InstantiationException | IllegalAccessException | InvocationTargetException e) {
//            System.out.println(e.getMessage());
            result = "Invalid command!";
        }

//		switch (commandName) {
//			case "add":
//				result = new AddUnit(data, this.repository, this.unitFactory).execute();
//				break;
//			case "report":
//				result = new Report(data, this.repository, this.unitFactory).execute();
//				break;
//			case "fight":
//				result = new Fight(data, this.repository, this.unitFactory).execute();
//				break;
//			default:
//				throw new RuntimeException("Invalid command!");
//		}
        return result;
    }

    private String getCorrectClassName(String name) {
        StringBuilder sb = new StringBuilder();
        sb.append(Character.toUpperCase(name.charAt(0)));
        sb.append(name.substring(1));

        return sb.toString();

    }
}
