package barracksWars.core.commands;

import barracksWars.core.commands.Command;
import barracksWars.interfaces.Repository;
import barracksWars.interfaces.UnitFactory;

//report command
public class Report extends Command {
    public Report(String[] data, Repository repository, UnitFactory factory) {
        super(data, repository, factory);
    }

    @Override
    public String execute() {
        return this.getRepository().getStatistics();
    }
}
