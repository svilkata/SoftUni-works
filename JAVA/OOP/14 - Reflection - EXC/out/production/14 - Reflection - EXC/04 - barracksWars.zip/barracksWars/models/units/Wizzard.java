package barracksWars.models.units;

public class Wizzard extends AbstractUnit {

    protected Wizzard() {
        super(999, 666);
    }
}
