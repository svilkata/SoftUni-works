package restaurant;

import java.math.BigDecimal;

public class Soup extends Starter {
    public Soup(String name, BigDecimal bigDecimal, double grams) {
        super(name, bigDecimal, grams);
    }
}

