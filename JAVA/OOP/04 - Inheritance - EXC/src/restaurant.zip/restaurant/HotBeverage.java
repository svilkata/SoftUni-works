package restaurant;

import java.math.BigDecimal;

public class HotBeverage extends Beverage {
    public HotBeverage(String name, BigDecimal bigDecimal, double milliliters) {
        super(name, bigDecimal, milliliters);
    }


}
