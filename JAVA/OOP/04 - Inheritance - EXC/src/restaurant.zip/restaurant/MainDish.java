package restaurant;

import java.math.BigDecimal;

public class MainDish extends Food {
    public MainDish(String name, BigDecimal bigDecimal, double grams) {
        super(name, bigDecimal, grams);
    }
}
