package restaurant;

import java.math.BigDecimal;

public class ColdBeverage extends Beverage {
    public ColdBeverage(String name, BigDecimal bigDecimal, double milliliters) {
        super(name, bigDecimal, milliliters);
    }
}
