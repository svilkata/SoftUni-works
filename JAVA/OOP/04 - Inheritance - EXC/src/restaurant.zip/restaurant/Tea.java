package restaurant;

import java.math.BigDecimal;

public class Tea extends HotBeverage {
    public Tea(String name, BigDecimal bigDecimal, double milliliters) {
        super(name, bigDecimal, milliliters);
    }
}
